#!/bin/bash
echo "install ${NGINX_PREFIX}:"
exit 1